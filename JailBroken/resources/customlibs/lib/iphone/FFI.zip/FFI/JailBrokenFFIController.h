//
//  JailBrokenFFIController.h
//  VMAppWithKonylib
//
//  Created by Paramatma on 6/18/15.
//
//

#import <Foundation/Foundation.h>

@interface JailBrokenFFIController : NSObject {

}

+ (BOOL) isJailBrokenDevice;

@end
